import './signup.css';
import React from 'react'; // Import your CSS file

const YourComponentName = () => {
  return (
    <>
    <div>aksdfhaishii</div>

    </>
  );
};

export default YourComponentName;
