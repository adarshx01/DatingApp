import React, { useEffect, useState } from 'react';
import './matchcard.css';
import PropTypes from 'prop-types';
import MatchCard from './matchcard.js';
import { collection, getDocs } from 'firebase/firestore';
import { db } from './Firebase';

const Match = () => {
  const storedAnswers = JSON.parse(localStorage.getItem("Answers"));
console.log('Stored Answers:', storedAnswers);
  console.log(storedAnswers[0]);
  const [peopleData, setPeopleData] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'users'));
        const data = querySnapshot.docs.map((doc) => ({
          id: doc.id, // Use 'id' property for document ID (email address)
          ...doc.data(),
        }));
        setPeopleData(data);
      } catch (error) {
        console.error('Error fetching data from Firebase:', error);
      }
    };

    fetchData();
    // Set the current user data
    setCurrentUser({
      Name: localStorage.getItem("UserName"),
      Email: localStorage.getItem("Useremail"),
      Password: localStorage.getItem("Password"),
      Gender: localStorage.getItem("Gender"),
      DOB: localStorage.getItem("DOB"),
      Instagram:localStorage.getItem("Instagram"),
      Abouts:localStorage.getItem("Abouts"),
      question1: storedAnswers[0],
      question2: storedAnswers[1],
      question3: storedAnswers[2],
      question4: storedAnswers[3],
      question5: storedAnswers[4],
      question6: storedAnswers[5],
      question7: storedAnswers[6],
      question8: storedAnswers[7],
      question9: storedAnswers[8],
      question10: storedAnswers[9],
      question11: storedAnswers[10],
      question12: storedAnswers[11],
      question13: storedAnswers[12],
      question14: storedAnswers[13],
      question15: storedAnswers[14] 
    });
  }, []);

  // Function to calculate compatibility
  const calculateCompatibility = (user1, user2) => {
    let totalScore = 0;

    
    for (const question in user1) {
      if (user1.hasOwnProperty(question) && user2.hasOwnProperty(question)) {
        
        if (user1[question] === user2[question]) {
          totalScore += 1; // Increase the score
        }
      }
    }

    return totalScore;
  };

  // Find the most compatible person
  const mostCompatiblePerson = peopleData
    .filter(person => person.Gender !== currentUser?.Gender) // gender preference
    .reduce((mostCompatible, person) => {
      const compatibilityScore = calculateCompatibility(currentUser, person);

      if (compatibilityScore > mostCompatible.score) {
        return { person, score: compatibilityScore };
      } else {
        return mostCompatible;
      }
    }, { person: null, score: -1 }).person;

  return (
    <div className="card-container">
      {mostCompatiblePerson && (
        <MatchCard
          Name={mostCompatiblePerson.Name}
          age={mostCompatiblePerson.DOB}
          abouts={mostCompatiblePerson.Abouts}
        />
      )}
    </div>
  );
};

export default Match;
