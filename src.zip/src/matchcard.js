// matchcard.js
import './matchcard.css';
import React from 'react';
import PropTypes from 'prop-types';
const MatchCard = ( props ) => {
  let {Name,age,abouts} = props;

  return (
    <div className='container my-3'>
      <div className="card">
        <div className="content">
          <div className="back">
            <div className="back-content">
              <svg
                stroke="#ffffff"
                xmlnsXlink="http://www.w3.org/1999/xlink"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 50 50"
                height="50px"
                width="50px"
                fill="#ffffff"
              >
              </svg>
              <strong>{Name} {age}'</strong>
            </div>
          </div>
          <div className="front">
            <div className="img">
              <div className="circle"></div>
              <div className="circle" id="right"></div>
              <div className="circle" id="bottom"></div>
            </div>
            <div className="front-content">
              <small className="badge">cuisine</small>
              <div className="description">
                <div className="title">
                  <p className="title">
                    <strong>{age}</strong>
                  </p>
                  <svg
                    fillRule="nonzero"
                    height="15px"
                    width="15px"
                    viewBox="0,0,256,256"
                    xmlnsXlink="http://www.w3.org/1999/xlink"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                  </svg>
                </div>
                <p className="card-footer">{abouts}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MatchCard;
